import UIKit

// constant
let time = 1

// Control flow code and results
for time in 1...180 {
    time + 1
    if time > 180 {
        break
    } else {
        if (time / 60) == 3 {
            print("\(time / 60) minutes")
        } else if (time / 60) >= 2 {
            if time == 120 {
                print("\(time / 60) minutes")
            } else if time - 120 == 1 {
                print("\(time / 60) minutes \(time - 120) second")
            } else {
                print("\(time / 60) minutes \(time - 120) seconds")
            }
        } else if (time / 60) >= 1 {
            if time == 60 {
                print("\(time / 60) minute")
            } else if time - 60 == 1 {
                print("\(time / 60) minute \(time - 60) second")
            } else {
                print("\(time / 60) minute \(time - 60) seconds")
            }
        } else if time < 60 {
            if time == 1 {
                print("\(time) second")
            } else  {
                print("\(time) seconds")
            }
        }
}
}
